package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText e1, e2;
    TextView t1, t2;
    Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        e1 = (EditText) findViewById(R.id.name);
        e2 = (EditText) findViewById(R.id.pwd);
        t1 = (TextView) findViewById(R.id.tv1);
        t2 = (TextView) findViewById(R.id.tv2);
        btn = (Button) findViewById(R.id.btn);
        btn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                if (e1.getText().toString().equals("Vijay") &&
                        e2.getText().toString().equals("Vijaypatil@12"))
                {
                    Toast.makeText(getApplicationContext(), "Welcome to Birds Info",
                            Toast.LENGTH_LONG).show();
                    Intent i1 = new Intent(getApplicationContext(), Welcome.class);
                    i1.putExtra("username", e1.getText().toString());
                    startActivity(i1);
                } else
                {
                    Toast.makeText(getApplicationContext(), "Login Failure",
                            Toast.LENGTH_LONG).show();
                }
            }
        });


    }
}